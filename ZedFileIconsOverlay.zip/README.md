﻿# Zed File Icons Overlay

This overlay applies VS Code-style file icons to files associated with official Stable Zed on Windows Explorer.

## Install

From this directory:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\install.ps1
```

The script copies icons to `%LOCALAPPDATA%\ZedFileIcons\file-icons` and writes `HKCU\Software\Classes\Zed.<ext>\DefaultIcon`.

## Uninstall

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\uninstall.ps1
```

If Explorer keeps showing old icons after installation, sign out and back in, or clear the Windows icon cache.
